CREATE TABLE complex (
	complexID INT PRIMARY KEY,
    completed BOOLEAN,
    country VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    street VARCHAR(200) NOT NULL,
    zipcode VARCHAR(20) NOT NULL
);

CREATE TABLE building (
    buildingID INT PRIMARY KEY,
    complexID INT NOT NULL,
    completed BOOLEAN,
    buildingName VARCHAR(100) NOT NULL,
    FOREIGN KEY (complexID) REFERENCES complex(complexID)
);

#unique id within a building is enough
CREATE TABLE wing (
    wingID INT PRIMARY KEY,
    buildingID INT NOT NULL,
    inBuildingID VARCHAR(2) NOT NULL,
    wingName VARCHAR(50) NOT NULL,
    proxInSwimming INT,
    proxOutSwimming INT,
    proxParking INT,
    proxHandi INT,
    FOREIGN KEY (buildingID) REFERENCES building(buildingID)
);

CREATE TABLE floor (
    floorID INT PRIMARY KEY,
    wingID INT NOT NULL,
    floorNumber INT NOT NULL,
    smokingFacility BOOLEAN NOT NULL,
    smokingFloor BOOLEAN NOT NULL, 
    FOREIGN KEY (wingID) REFERENCES wing(wingID)
);

#Room types and facilities 

CREATE TABLE room_function(
	roomFunctionID INT PRIMARY KEY AUTO_INCREMENT,
    roomFunctionName VARCHAR(50) NOT NULL
);

#e.g. Deluxe room (2-4)
CREATE TABLE room_type (
    roomTypeID INT PRIMARY KEY,
    sizeLabel VARCHAR(50) NOT NULL,
    price DECIMAL(10, 2) NOT NULL
);

#such as toilette, safe...
CREATE TABLE room_feature_type (
    featureTypeID INT PRIMARY KEY,
    featureName VARCHAR(100) NOT NULL
);

#all sleeping room has the 
CREATE TABLE room_feature_relation (
    roomTypeID INT NOT NULL,
    featureTypeID INT NOT NULL,
    PRIMARY KEY (roomTypeID, featureTypeID),
    FOREIGN KEY (roomTypeID) REFERENCES room_type(roomTypeID),
    FOREIGN KEY (featureTypeID) REFERENCES room_feature_type(featureTypeID)
);

#not quite right... need fixing
CREATE TABLE facility (
    facilityID INT PRIMARY KEY,
    roomTypeID INT,
    buildingID INT,
    position VARCHAR(100),
    FOREIGN KEY (roomTypeID) REFERENCES room_type(roomTypeID),
    FOREIGN KEY (buildingID) REFERENCES building(buildingID)
);



#### room status 

CREATE TABLE room_status (
    statusID INT PRIMARY KEY,
    statusName VARCHAR(50)
);

CREATE TABLE room (
    roomID INT PRIMARY KEY,
    floorID INT,
    roomNumber VARCHAR(20),
    roomTypeID INT,
    capacity INT,
    smokingRoom BOOLEAN,
    FOREIGN KEY (floorID) REFERENCES floor(floorID),
    FOREIGN KEY (roomTypeID) REFERENCES room_type(roomTypeID)
);



#### customers
CREATE TABLE customer_type (
    customerTypeID INT PRIMARY KEY,
    description VARCHAR(50)
);

CREATE TABLE customer (
    customerID INT PRIMARY KEY,
    name VARCHAR(150),
    phone VARCHAR(50),
    email VARCHAR(150),
    gender VARCHAR(20)
);
	

CREATE TABLE customer_call (
    callID INT PRIMARY KEY,
    customerID INT,
    message TEXT,
    callTime DATETIME,
    FOREIGN KEY (customerID) REFERENCES customer(customerID)
);

CREATE TABLE customer_call_outcome (
    customerID INT,
    callID INT,
    outcomeType VARCHAR(50),
    fee DECIMAL(10,2),
    PRIMARY KEY (customerID, callID),
    FOREIGN KEY (customerID) REFERENCES customer(customerID),
    FOREIGN KEY (callID) REFERENCES customer_call(callID)
);


#### reservations 

CREATE TABLE event (
    eventID INT PRIMARY KEY,
    roomNeeded BOOLEAN,
    estimatedAttendance INT,
    estimatedStartDate DATE NOT NULL,
    estimatedEndDate DATE NOT NULL,
    customerID INT NOT NULL,
    customerTypeID INT NOT NULL,
    billingParty BOOLEAN NOT NULL,
    FOREIGN KEY (customerID) REFERENCES customer(customerID),
    FOREIGN KEY (customerTypeID) REFERENCES customer_type(customerTypeID)
);

CREATE TABLE reservation (
    reservationID INT PRIMARY KEY,
    customerID INT NOT NULL,
    billingParty BOOLEAN NOT NULL,
    eventID INT,
    startDate DATE,
    endDate DATE,
    checkOutDate TIMESTAMP,
    channel VARCHAR(50),
    status VARCHAR(50),
    FOREIGN KEY (customerID) REFERENCES customer(customerID),
    FOREIGN KEY (eventID) REFERENCES event(eventID)
);

CREATE TABLE meeting_room_reservation (
    meetingRoomReservationID INT PRIMARY KEY,
    reservationsReserved INT NOT NULL,
    eventID INT,
    startDate DATE,
    endDate DATE,
    description VARCHAR(500),
    FOREIGN KEY (reservationsReserved) REFERENCES reservation(reservationID),
    FOREIGN KEY (eventID) REFERENCES event(eventID)
);



CREATE TABLE room_availability (
    roomID INT,
    statusID INT,
    timestamp DATE,
    PRIMARY KEY(roomID, statusID, timestamp),
    FOREIGN KEY (roomID) REFERENCES room(roomID),
    FOREIGN KEY (statusID) REFERENCES room_status(statusID)
);

CREATE TABLE room_assignment (
    reservationID INT,
    roomID INT,
    PRIMARY KEY (reservationID, roomID),
    FOREIGN KEY (reservationID) REFERENCES reservation(reservationID),
    FOREIGN KEY (roomID) REFERENCES room(roomID)
);

#### billing, payment 
CREATE TABLE billing (
    billingID INT PRIMARY KEY,
    reservationID INT NOT NULL,
    -- billig party, might be different from using group
    customerID INT NOT NULL,
    FOREIGN KEY (reservationID) REFERENCES reservation(reservationID),
    FOREIGN KEY (customerID) REFERENCES customer(customerID)
);

CREATE TABLE payment (
    paymentID INT PRIMARY KEY,
    billingID INT,
    date DATE,
    method VARCHAR(50),
    FOREIGN KEY (billingID) REFERENCES billing(billingID)
);

CREATE TABLE customer_payment_relation (
    customerID INT,
    paymentID INT,
    PRIMARY KEY (customerID, paymentID),
    FOREIGN KEY (customerID) REFERENCES customer(customerID),
    FOREIGN KEY (paymentID) REFERENCES payment(paymentID)
);

CREATE TABLE charged_service_type(
	serviceTypeId INT PRIMARY KEY,
    serviceDescription VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL
);

CREATE TABLE charged_service (
    chargedServiceId INT PRIMARY KEY,
    serviceTypeId INT NOT NULL,
    reservationID INT,
    customerID INT,
    amount DECIMAL(10,2) NOT NULL,
    time DATE NOT NULL,
    FOREIGN KEY (serviceTypeId) REFERENCES charged_service_type(serviceTypeId),
    FOREIGN KEY (reservationID) REFERENCES reservation(reservationID),
    FOREIGN KEY (customerID) REFERENCES customer(customerID)
);



#### staff, roles, staff logs 

CREATE TABLE staff_role (
    roleID INT PRIMARY KEY,
    roleType VARCHAR(50),
    description VARCHAR(200)
);

CREATE TABLE staff (
    staffID INT PRIMARY KEY,
    name VARCHAR(150),
    gender VARCHAR(20),
    hireDate DATE,
    department VARCHAR(100),
    phone VARCHAR(50)
);

CREATE TABLE staff_assignment (
    staffID INT,
    roleID INT,
    reservationID INT,
    description VARCHAR(200),
    PRIMARY KEY (staffID, roleID),
    FOREIGN KEY (staffID) REFERENCES staff(staffID),
    FOREIGN KEY (roleID) REFERENCES staff_role(roleID),
    FOREIGN KEY (reservationID) REFERENCES reservation(reservationID)
);

CREATE TABLE staff_log (
    logID INT PRIMARY KEY,
    staffID INT,
    reservationID INT,
    action VARCHAR(100),
    time DATETIME,
    FOREIGN KEY (staffID) REFERENCES staff(staffID),
    FOREIGN KEY (reservationID) REFERENCES reservation(reservationID)
);


-- Room-related 
INSERT INTO room_function (roomFunctionName) VALUES
('Sleeping'),
('Meeting'),
('Eating'),
('Event Hosting'),
('Recreation');

-- INSERT INTO bed_kind (bedKindName) VALUES
-- ('Regular'),
-- ('Extra Long'),
-- 'Queen'),
-- ('King'),
-- ('Rollaway'),
-- ('Fold-up Wall Bed');

-- building-related
INSERT INTO complex (complexID, completed, country, state, city, street, zipcode) VALUES
(1, TRUE, 'USA', 'California', 'Los Angeles', '123 Sunset Blvd', '90028'),
(2, TRUE, 'France', 'Provence-Alpes-Côte d''Azur', 'Nice', '45 Promenade des Anglais', '06000'),
(3, TRUE, 'Japan', 'Tokyo', 'Tokyo', '1-2-3 Shibuya', '150-0002'),
(4, FALSE, 'UAE', 'Dubai', 'Dubai', 'Sheikh Zayed Rd', '00000'),
(5, TRUE, 'UK', 'England', 'London', '12 Park Lane', 'W1K 7AA'),
(6, TRUE, 'Australia', 'NSW', 'Sydney', '100 George Street', '2000');


INSERT INTO building (buildingID, complexID, completed, buildingName) VALUES
(1, 1, TRUE, 'Sunset Tower'),
(2, 1, TRUE, 'Mediterranean Palace'),
(3, 1, TRUE, 'Sakura Gardens'),
(4, 1, FALSE, 'Desert Oasis (Under Construction)'),
(5, 2, TRUE, 'London Grand'),
(6, 3, TRUE, 'Sydney Harbour View');

INSERT INTO wing (wingID, buildingID, inBuildingID, wingName, proxInSwimming, proxOutSwimming, proxParking, proxHandi) VALUES
(1, 1, 'A', 'Apple', 10, 150, 20, 10),
(2, 1, 'B', 'Banana', 100, 50, 90, 10),
(3, 2, 'A', 'North', 10, 190, 50, 10),
(4, 2, 'B', 'South', 100, 20, 100, 10),
(5, 3, 'A', 'East', 10, 200, 200, 10),
(6, 3, 'B', 'West', 100, 20, 120, 10),
(7, 4, 'A', 'Main', 10, 100, 200, 10),
(8, 5, 'A', 'Royal', 10, 300, 300, 10),
(9, 6, 'A', 'Harbour', 10, 200, 100, 10);

INSERT INTO floor (floorID, wingID, floorNumber, smokingFacility, smokingFloor) VALUES
(1, 1, 1, TRUE, FALSE),
(2, 1, 2, TRUE, TRUE),
(3, 2, 1, TRUE, FALSE),
(4, 2, 2, TRUE, FALSE),
(5, 3, 1, TRUE, FALSE),
(6, 3, 2, FALSE, FALSE),
(7, 4, 1, FALSE, FALSE),
(8, 5, 1, TRUE, TRUE),
(9, 5, 2, TRUE, FALSE),
(10, 6, 1, FALSE, FALSE);

INSERT INTO room_type (roomTypeID, sizeLabel, price) VALUES
(1, 'Single Occupancy (1-2)', 100.00),
(2, 'Double Occupancy (2)', 150.00),
(3, 'Family Suite (2-4)', 200.00),
(4, 'Executive Suite (3-5)', 500.00),
(5, 'Small Meeting Room (4-12)', 750.50),
(6, 'Large Ballroom (200-1000+)', 5500.00),
(7, 'Conference Room (12-30)', 1200.75),
(8, 'Presidential Suite (3-6+)', 8500.99),
(9, 'Standard Suite (2-4)', 350.49),
(10, 'Deluxe Room (2-4)', 480.25),
(11, 'Large Conference Room (50-100)', 3000.00);

INSERT INTO room_feature_type (featureTypeID, featureName) VALUES
(1, 'Toilet and Bath'),
(2, 'Telephone'),
(3, 'Television'),
(4, 'Closet'),
(5, 'Drawers'),
(6, 'Movable Walls'),
(7, 'Private Access Door'),
(8, 'Fold-up Bed'),
(9, 'Mini Bar'),
(10, 'Coffee Machine'),
(11, 'Safe'),
(12, 'Balcony'),
(13, 'Extra Small Space'),
(14, 'Extra Large Space w/ Meeting Functionality'),
(15, 'Rollaway Bed Feasibility'),
(16, 'Separate Room for Meeting/Working');


INSERT INTO room_feature_relation (roomTypeID, featureTypeID) VALUES
(1, 1), (1, 2), (1, 3), (1, 4), (1, 5),
(2, 1), (2, 2), (2, 3), (2, 4), (2, 5), (2, 9),
(3, 1), (3, 2), (3, 3), (3, 4), (3, 5), (3, 7), (3, 9), (3, 10), (3, 16),
(4, 1), (4, 2), (4, 3), (4, 4), (4, 5), (4, 7), (4, 9), (4, 10), (4, 11), (4, 12), (4, 16),
(5, 2), (5, 6), 
(6, 1), (6, 2), (6, 3), (6, 6), (6, 9), (6, 10),
(7, 1), (7, 2), (7, 3), (7, 10),
(8, 1), (8, 2), (8, 3), (8, 4), (8, 5), (8, 7), (8, 9), (8, 10), (8, 11), (8, 12),
(9, 1), (9, 2), (9, 3), (9, 4), (9, 5), (9, 7), (9, 10), (9, 11), (9, 12), (9, 16),
(10, 1), (10, 2), (10, 3), (10, 4), (10, 5), (10, 7), (10, 10), (10, 11), (10, 12),
(11, 1), (11, 2), (11, 3), (11, 6), (11, 9), (11, 10);

#not quite right...
INSERT INTO facility (facilityID, roomTypeID, buildingID, position) VALUES
(1, 1, 1, 'First floor, near elevator'),
(2, 2, 1, 'Second floor, corner room'),
(3, 3, 1, 'Third floor, sea view'),
(4, 4, 2, 'Top floor, panoramic view'),
(5, 5, 2, 'Ground floor, near lobby'),
(6, 6, 3, 'Main hall, ground floor'),
(7, 7, 3, 'Conference wing'),
(8, 8, 4, 'Penthouse'),
(9, 9, 5, 'Executive floor'),
(10, 10, 6, 'Harbour view rooms');

INSERT INTO room_status (statusID, statusName) VALUES
(1, 'Available'),
(2, 'Occupied'),
(3, 'Under Maintenance'),
(4, 'Being Cleaned'),
(5, 'Reserved'),
(6, 'Out of Service'),
(7, 'Ready for Check-in');

INSERT INTO room (roomID, floorID, roomNumber, roomTypeID, capacity, smokingRoom) VALUES
(1, 1, 'A1101', 1, 2, TRUE),
(2, 1, 'A1102', 2, 4, TRUE),
(3, 2, 'B1201', 3, 6, TRUE),
(4, 2, 'B1202', 4, 2, TRUE),
(5, 3, 'C2303', 1, 2, TRUE),
(6, 3, 'C2304', 2, 4, FALSE),
(7, 4, 'C0301', 5, 20, TRUE),
(8, 5, 'C0401', 6, 10000, FALSE),
(9, 6, 'C0501', 7, 50, FALSE),
(10, 7, 'E1601', 8, 4, TRUE),
(11, 8, 'E1701', 9, 4, TRUE),
(12, 9, 'A0801', 10, 2, FALSE),
(13, 10, 'B0901', 1, 2, FALSE),
(14, 1, 'A1505', 2, 4, TRUE),
(15, 2, 'B3203', 3, 6, FALSE);

INSERT INTO room_availability (roomID, statusID, timestamp) VALUES
(1, 4, '2025-02-01 08:30:00'),   -- Being Cleaned
(1, 7, '2025-02-01 10:15:00'),   -- Ready for Check-in
(1, 2, '2025-02-01 15:00:00'),   -- Occupied
(1, 4, '2025-02-02 09:30:00'),   -- Being Cleaned
(1, 1, '2025-02-02 11:00:00'),   -- Available

(2, 5, '2025-02-01 12:00:00'),   -- Reserved
(2, 7, '2025-02-02 14:30:00'),   -- Ready for Check-in
(2, 2, '2025-02-02 16:00:00'),   -- Occupied

(3, 6, '2025-01-31 15:00:00'),   -- Out of Service
(3, 3, '2025-02-01 09:00:00'),   -- Under Maintenance
(3, 4, '2025-02-02 13:00:00'),   -- Being Cleaned
(3, 1, '2025-02-03 08:00:00'),   -- Available

(4, 4, '2025-02-01 07:45:00'),   -- Being Cleaned
(4, 7, '2025-02-01 09:30:00'),   -- Ready for Check-in
(4, 2, '2025-02-01 14:00:00'),   -- Occupied

(5, 1, '2025-02-01 10:00:00'),   -- Available
(5, 5, '2025-02-02 13:30:00'),   -- Reserved

(6, 4, '2025-01-31 16:00:00'),   -- Being Cleaned
(6, 7, '2025-02-01 08:45:00'),   -- Ready for Check-in
(6, 1, '2025-02-01 09:30:00'),   -- Available

(7, 4, '2025-01-31 12:00:00'),   -- Being Cleaned
(7, 4, '2025-02-01 08:00:00'),   -- Still being cleaned
(7, 1, '2025-02-01 11:30:00'),   -- Available

(8, 3, '2025-01-30 09:00:00'),   -- Under Maintenance
(8, 6, '2025-01-31 14:20:00'),   -- Out of Service

(9, 4, '2025-02-01 07:50:00'),   -- Being Cleaned
(9, 7, '2025-02-01 10:20:00'),   -- Ready
(9, 1, '2025-02-01 10:45:00'),   -- Available

(10, 5, '2025-02-02 11:00:00'),  -- Reserved

(11, 1, '2025-02-01 12:00:00'),  -- Available

(12, 6, '2025-02-01 13:00:00'),  -- Out of Service

(13, 4, '2025-02-01 09:20:00'),  -- Being Cleaned
(13, 7, '2025-02-01 12:15:00'),  -- Ready

(14, 5, '2025-02-02 09:00:00'),  -- Reserved

(15, 3, '2025-02-01 08:40:00'),  -- Under Maintenance
(15, 4, '2025-02-02 09:15:00');  -- Being Cleaned



INSERT INTO customer_type (customerTypeID, description) VALUES
(1, 'Individual Guest'),
(2, 'Corporate Client'),
(3, 'Event Host'),
(4, 'Travel Agency'),
(5, 'Government Entity');

INSERT INTO customer (customerID, name, phone, email, gender) VALUES
(1, 'John Smith', '+1-555-0101', 'john.smith@email.com', 'Male'),
(2, 'TechCorp Inc.', '+1-555-0102', 'contact@techcorp.com', NULL),
(3, 'Alice Johnson', '+1-555-0103', 'alice.j@email.com', 'Female'),
(4, 'World Travel Agency', '+1-555-0104', 'bookings@worldtravel.com', NULL),
(5, 'City of Los Angeles', '+1-555-0105', 'events@la.gov', NULL),
(6, 'Robert Brown', '+1-555-0106', 'robert.b@email.com', 'Male'),
(7, 'Maria Garcia', '+1-555-0107', 'maria.g@email.com', 'Female'),
(8, 'Global Foods LLC', '+1-555-0108', 'info@globalfoods.com', NULL),
(9, 'David Wilson', '+1-555-0109', 'david.w@email.com', 'Male'),
(10, 'Sarah Miller', '+1-555-0110', 'sarah.m@email.com', 'Female'),
(11, 'Michael Davis', '+1-555-0111', 'michael.d@email.com', 'Male'),
(12, 'Innovate Solutions', '+1-555-0112', 'info@innovatesolutions.com', NULL),
(13, 'Jennifer Taylor', '+1-555-0113', 'jennifer.t@email.com', 'Female'),
(14, 'Thomas Anderson', '+1-555-0114', 'thomas.a@email.com', 'Male'),
(15, 'Emily Clark', '+1-555-0115', 'emily.c@email.com', 'Female'),
(16, 'Global Voyages', '+1-555-0116', 'reservations@globalvoyages.com', NULL),
(17, 'Christopher Lee', '+1-555-0117', 'chris.lee@email.com', 'Male'),
(18, 'MediTech Corp', '+1-555-0118', 'contact@meditech.com', NULL),
(19, 'Amanda White', '+1-555-0119', 'amanda.w@email.com', 'Female'),
(20, 'Daniel Martinez', '+1-555-0120', 'daniel.m@email.com', 'Male'),
(21, 'Sophia Robinson', '+1-555-0121', 'sophia.r@email.com', 'Female'),
(22, 'Kevin Harris', '+1-555-0122', 'kevin.h@email.com', 'Male'),
(23, 'Future Tech Ltd', '+1-555-0123', 'info@futuretech.com', NULL),
(24, 'Olivia Walker', '+1-555-0124', 'olivia.w@email.com', 'Female'),
(25, 'State Department', '+1-555-0125', 'travel@statedept.gov', NULL),
(26, 'Matthew King', '+1-555-0126', 'matthew.k@email.com', 'Male'),
(27, 'Jessica Scott', '+1-555-0127', 'jessica.s@email.com', 'Female'),
(28, 'Benjamin Young', '+1-555-0128', 'benjamin.y@email.com', 'Male'),
(29, 'Green Energy Inc', '+1-555-0129', 'contact@greenenergy.com', NULL),
(30, 'Elizabeth Hall', '+1-555-0130', 'elizabeth.h@email.com', 'Female'),
(31, 'Andrew Allen', '+1-555-0131', 'andrew.a@email.com', 'Male'),
(32, 'Luxury Travel Co', '+1-555-0132', 'info@luxurytravel.com', NULL),
(33, 'Megan Wright', '+1-555-0133', 'megan.w@email.com', 'Female'),
(34, 'Creative Designs', '+1-555-0134', 'contact@creativedesigns.com', NULL),
(35, 'Ryan Lopez', '+1-555-0135', 'ryan.l@email.com', 'Male'),
(36, 'Grace Hill', '+1-555-0136', 'grace.h@email.com', 'Female'),
(37, 'Joshua Green', '+1-555-0137', 'joshua.g@email.com', 'Male'),
(38, 'Brittany Adams', '+1-555-0138', 'brittany.a@email.com', 'Female'),
(39, 'Precision Tools', '+1-555-0139', 'sales@precisiontools.com', NULL),
(40, 'Alexander Nelson', '+1-555-0140', 'alexander.n@email.com', 'Male'),
(41, 'County Council', '+1-555-0141', 'admin@countycouncil.gov', NULL),
(42, 'Victoria Carter', '+1-555-0142', 'victoria.c@email.com', 'Female'),
(43, 'Samuel Mitchell', '+1-555-0143', 'samuel.m@email.com', 'Male'),
(44, 'Lauren Perez', '+1-555-0144', 'lauren.p@email.com', 'Female'),
(45, 'Quality Foods', '+1-555-0145', 'info@qualityfoods.com', NULL),
(46, 'Nathan Roberts', '+1-555-0146', 'nathan.r@email.com', 'Male'),
(47, 'Hannah Turner', '+1-555-0147', 'hannah.t@email.com', 'Female'),
(48, 'Adventure Tours', '+1-555-0148', 'book@adventuretours.com', NULL),
(49, 'Isaac Phillips', '+1-555-0149', 'isaac.p@email.com', 'Male'),
(50, 'Rachel Campbell', '+1-555-0150', 'rachel.c@email.com', 'Female');


INSERT INTO customer_call (callID, customerID, message, callTime) VALUES
(1, 1, 'Requested late check-out', '2024-11-01 10:30:00'),
(2, 2, 'Inquiry about conference facilities', '2024-11-02 14:15:00'),
(3, 3, 'Changed reservation dates', '2024-11-03 09:45:00'),
(4, 4, 'Group booking inquiry', '2024-11-04 16:20:00'),
(5, 5, 'Government event coordination', '2024-11-05 11:10:00'),
(6, 6, 'Room upgrade request', '2024-11-06 13:25:00'),
(7, 7, 'Special dietary requirements', '2024-11-07 10:05:00'),
(8, 8, 'Corporate account setup', '2024-11-08 15:30:00'),
(9, 9, 'Event planning consultation', '2024-11-09 12:15:00'),
(10, 10, 'Honeymoon package inquiry', '2024-11-10 09:20:00');

INSERT INTO customer_call_outcome (customerID, callID, outcomeType, fee) VALUES
(1, 1, 'Late Check-out Approved', 50.00),
(2, 2, 'Facility Tour Scheduled', 0.00),
(3, 3, 'Reservation Modified', 0.00),
(4, 4, 'Group Quote Provided', 0.00),
(5, 5, 'Event Contract Sent', 0.00),
(6, 6, 'Upgrade Confirmed', 75.00),
(7, 7, 'Dietary Needs Noted', 0.00),
(8, 8, 'Account Created', 0.00),
(9, 9, 'Planning Session Scheduled', 0.00),
(10, 10, 'Package Details Sent', 0.00);

INSERT INTO event (eventID, roomNeeded, estimatedAttendance, estimatedStartDate, estimatedEndDate, customerID, customerTypeID, billingParty)
VALUES
(1, TRUE, 120, '2025-02-10', '2025-02-12', 7, 3, TRUE),
(2, FALSE, 45, '2025-03-05', '2025-03-05', 12, 1, FALSE),
(3, TRUE, 300, '2025-04-01', '2025-04-03', 25, 4, TRUE),
(4, TRUE, 80, '2025-05-15', '2025-05-16', 49, 2, TRUE),
(5, FALSE, 20, '2025-01-20', '2025-01-20', 33, 5, FALSE),
(6, TRUE, 150, '2025-06-10', '2025-06-12', 18, 2, TRUE),
(7, FALSE, 60, '2025-02-28', '2025-03-01', 5, 1, TRUE),
(8, TRUE, 220, '2025-07-14', '2025-07-15', 41, 3, TRUE),
(9, TRUE, 90, '2025-03-22', '2025-03-23', 28, 5, FALSE),
(10, FALSE, 35, '2025-04-18', '2025-04-18', 9, 4, TRUE),
(11, TRUE, 400, '2025-08-01', '2025-08-03', 17, 2, TRUE),
(12, FALSE, 50, '2025-05-09', '2025-05-10', 30, 1, FALSE),
(13, TRUE, 260, '2025-09-12', '2025-09-13', 44, 5, TRUE),
(14, TRUE, 110, '2025-10-05', '2025-10-06', 3, 4, TRUE),
(15, FALSE, 75, '2025-03-30', '2025-03-31', 22, 3, FALSE);


INSERT INTO reservation (reservationID, customerID, billingParty, eventID, startDate, endDate, checkOutDate, channel, status) VALUES
(1, 12, TRUE, NULL, '2024-01-11', '2024-01-14', '2024-01-14 10:00:00', 'Online', 'Checked Out'),
(2, 33, FALSE, 10, '2024-01-20', '2024-01-23', '2024-01-23 10:00:00', 'Phone', 'Checked Out'),
(3, 7, TRUE, NULL, '2024-02-02', '2024-02-06', '2024-02-06 10:00:00', 'Travel Agent', 'Checked Out'),
(4, 45, FALSE, 2, '2024-02-11', '2024-02-14', '2024-02-14 10:00:00', 'Online', 'Checked Out'),
(5, 26, TRUE, NULL, '2024-02-18', '2024-02-20', '2024-02-20 10:00:00', 'Email', 'Checked Out'),
(6, 4, FALSE, 13, '2024-03-01', '2024-03-04', '2024-03-04 10:00:00', 'Online', 'Checked Out'),
(7, 18, TRUE, NULL, '2024-03-09', '2024-03-11', '2024-03-11 10:00:00', 'Phone', 'Checked Out'),
(8, 50, FALSE, 7, '2024-03-15', '2024-03-20', '2024-03-20 10:00:00', 'Online', 'Checked Out'),
(9, 9, TRUE, NULL, '2024-03-25', '2024-03-28', '2024-03-28 10:00:00', 'Travel Agent', 'Checked Out'),
(10, 42, FALSE, 14, '2024-04-02', '2024-04-06', '2024-04-06 10:00:00', 'Online', 'Checked Out'),
(11, 13, TRUE, NULL, '2024-04-10', '2024-04-12', '2024-04-12 10:00:00', 'Email', 'Checked Out'),
(12, 37, FALSE, 3, '2024-04-15', '2024-04-20', '2024-04-20 10:00:00', 'Phone', 'Checked Out'),
(13, 22, TRUE, NULL, '2024-04-28', '2024-05-02', '2024-05-02 10:00:00', 'Online', 'Checked Out'),
(14, 6, FALSE, 5, '2024-05-03', '2024-05-06', '2024-05-06 10:00:00', 'Travel Agent', 'Checked Out'),
(15, 49, TRUE, NULL, '2024-05-10', '2024-05-12', '2024-05-12 10:00:00', 'Email', 'Checked Out'),
(16, 15, FALSE, 1, '2024-05-18', '2024-05-21', '2024-05-21 10:00:00', 'Online', 'Checked Out'),
(17, 29, TRUE, NULL, '2024-05-25', '2024-05-29', '2024-05-29 10:00:00', 'Phone', 'Checked Out'),
(18, 3, FALSE, 8, '2024-06-02', '2024-06-06', '2024-06-06 10:00:00', 'Online', 'Checked Out'),
(19, 21, TRUE, NULL, '2024-06-10', '2024-06-13', '2024-06-13 10:00:00', 'Email', 'Checked Out'),
(20, 30, FALSE, NULL, '2024-06-15', '2024-06-18', '2024-06-18 10:00:00', 'Travel Agent', 'Checked Out'),
(21, 14, TRUE, 11, '2024-06-22', '2024-06-25', '2024-06-25 10:00:00', 'Online', 'Checked Out'),
(22, 46, FALSE, NULL, '2024-06-30', '2024-07-03', '2024-07-03 10:00:00', 'Phone', 'Checked Out'),
(23, 10, TRUE, 4, '2024-07-05', '2024-07-08', '2024-07-08 10:00:00', 'Online', 'Checked Out'),
(24, 8, FALSE, NULL, '2024-07-12', '2024-07-15', '2024-07-15 10:00:00', 'Email', 'Checked Out'),
(25, 25, TRUE, 6, '2024-07-20', '2024-07-22', '2024-07-22 10:00:00', 'Online', 'Checked Out'),
(26, 38, FALSE, NULL, '2024-07-28', '2024-07-31', '2024-07-31 10:00:00', 'Phone', 'Checked Out'),
(27, 1, TRUE, 9, '2024-08-03', '2024-08-06', '2024-08-06 10:00:00', 'Online', 'Checked Out'),
(28, 44, FALSE, NULL, '2024-08-10', '2024-08-12', '2024-08-12 10:00:00', 'Travel Agent', 'Checked Out'),
(29, 5, TRUE, 15, '2024-08-15', '2024-08-18', '2024-08-18 10:00:00', 'Online', 'Checked Out'),
(30, 48, FALSE, NULL, '2024-08-22', '2024-08-25', '2024-08-25 10:00:00', 'Email', 'Checked Out'),
(31, 17, TRUE, 12, '2024-08-29', '2024-09-01', '2024-09-01 10:00:00', 'Online', 'Checked Out'),
(32, 34, FALSE, NULL, '2024-09-05', '2024-09-09', '2024-09-09 10:00:00', 'Phone', 'Checked Out'),
(33, 20, TRUE, 2, '2024-09-12', '2024-09-15', '2024-09-15 10:00:00', 'Online', 'Checked Out'),
(34, 19, FALSE, NULL, '2024-09-22', '2024-09-25', '2024-09-25 10:00:00', 'Travel Agent', 'Checked Out'),
(35, 40, TRUE, 7, '2024-10-01', '2024-10-04', '2024-10-04 10:00:00', 'Email', 'Checked Out'),
(36, 11, FALSE, NULL, '2024-10-08', '2024-10-10', '2024-10-10 10:00:00', 'Online', 'Checked Out'),
(37, 24, TRUE, 14, '2024-10-15', '2024-10-19', '2024-10-19 10:00:00', 'Phone', 'Checked Out'),
(38, 31, FALSE, NULL, '2024-10-20', '2024-10-23', '2024-10-23 10:00:00', 'Online', 'Checked Out'),
(39, 47, TRUE, 3, '2024-10-28', '2024-10-31', '2024-10-31 10:00:00', 'Email', 'Checked Out'),
(40, 2, FALSE, NULL, '2024-11-02', '2024-11-06', '2024-11-06 10:00:00', 'Travel Agent', 'Checked Out'),
(41, 39, TRUE, 6, '2024-11-10', '2024-11-12', '2024-11-12 10:00:00', 'Online', 'Checked Out'),
(42, 16, FALSE, NULL, '2024-11-14', '2024-11-17', '2024-11-17 10:00:00', 'Phone', 'Checked Out'),
(43, 41, TRUE, 10, '2024-11-20', '2024-11-22', '2024-11-22 10:00:00', 'Online', 'Checked Out'),
(44, 36, FALSE, NULL, '2024-11-29', '2024-12-02', '2024-12-02 10:00:00', 'Email', 'Checked Out'),
(45, 32, TRUE, 5, '2024-12-05', '2024-12-09', '2024-12-09 10:00:00', 'Online', 'Checked Out'),
(46, 23, FALSE, NULL, '2024-12-12', '2024-12-15', '2024-12-15 10:00:00', 'Phone', 'Checked Out'),
(47, 35, TRUE, 11, '2024-12-18', '2024-12-21', '2024-12-21 10:00:00', 'Online', 'Checked Out'),
(48, 28, FALSE, NULL, '2024-12-27', '2024-12-30', '2024-12-30 10:00:00', 'Travel Agent', 'Checked Out'),
(49, 43, TRUE, 1, '2025-01-02', '2025-01-05', '2025-01-05 10:00:00', 'Online', 'Checked Out'),
(50, 27, FALSE, NULL, '2025-01-08', '2025-01-12', '2025-01-12 10:00:00', 'Email', 'Checked Out'),
(51, 10, TRUE, 9, '2025-01-15', '2025-01-17', '2025-01-17 10:00:00', 'Online', 'Checked Out'),
(52, 38, FALSE, NULL, '2025-01-20', '2025-01-24', '2025-01-24 10:00:00', 'Phone', 'Checked Out'),
(53, 29, TRUE, 13, '2025-01-27', '2025-01-29', '2025-01-29 10:00:00', 'Email', 'Checked Out'),
(54, 1, FALSE, NULL, '2025-02-01', '2025-02-04', '2025-02-04 10:00:00', 'Online', 'Checked Out'),
(55, 46, TRUE, 3, '2025-02-08', '2025-02-12', '2025-02-12 10:00:00', 'Online', 'Checked Out'),
(56, 7, FALSE, NULL, '2025-02-16', '2025-02-18', '2025-02-18 10:00:00', 'Travel Agent', 'Checked Out'),
(57, 12, TRUE, 5, '2025-02-20', '2025-02-23', '2025-02-23 10:00:00', 'Email', 'Checked Out'),
(58, 34, FALSE, NULL, '2025-02-27', '2025-03-02', '2025-03-02 10:00:00', 'Phone', 'Checked Out'),
(59, 8, TRUE, 7, '2025-03-05', '2025-03-09', '2025-03-09 10:00:00', 'Online', 'Checked Out'),
(60, 4, FALSE, NULL, '2025-03-12', '2025-03-15', '2025-03-15 10:00:00', 'Travel Agent', 'Checked Out'),
(61, 24, TRUE, 14, '2025-03-18', '2025-03-21', '2025-03-21 10:00:00', 'Online', 'Checked Out'),
(62, 50, FALSE, NULL, '2025-03-24', '2025-03-26', '2025-03-26 10:00:00', 'Phone', 'Checked Out'),
(63, 13, TRUE, 2, '2025-03-29', '2025-04-02', '2025-04-02 10:00:00', 'Online', 'Checked Out'),
(64, 6, FALSE, NULL, '2025-04-04', '2025-04-07', '2025-04-07 10:00:00', 'Email', 'Checked Out'),
(65, 25, TRUE, 10, '2025-04-10', '2025-04-14', '2025-04-14 10:00:00', 'Online', 'Checked Out'),
(66, 17, FALSE, NULL, '2025-04-18', '2025-04-20', '2025-04-20 10:00:00', 'Travel Agent', 'Checked Out'),
(67, 41, TRUE, 1, '2025-04-22', '2025-04-26', '2025-04-26 10:00:00', 'Online', 'Checked Out'),
(68, 35, FALSE, NULL, '2025-04-29', '2025-05-01', '2025-05-01 10:00:00', 'Phone', 'Checked Out'),
(69, 47, TRUE, 12, '2025-05-03', '2025-05-06', '2025-05-06 10:00:00', 'Online', 'Checked Out'),
(70, 21, FALSE, NULL, '2025-05-08', '2025-05-11', '2025-05-11 10:00:00', 'Email', 'Checked Out'),
(71, 3, TRUE, 7, '2025-05-14', '2025-05-17', '2025-05-17 10:00:00', 'Online', 'Checked Out'),
(72, 44, FALSE, NULL, '2025-05-20', '2025-05-23', '2025-05-23 10:00:00', 'Travel Agent', 'Checked Out'),
(73, 26, TRUE, 4, '2025-05-28', '2025-05-31', '2025-05-31 10:00:00', 'Online', 'Checked Out'),
(74, 40, FALSE, NULL, '2025-06-02', '2025-06-04', '2025-06-04 10:00:00', 'Phone', 'Checked Out'),
(75, 2, TRUE, 11, '2025-06-06', '2025-06-09', '2025-06-09 10:00:00', 'Email', 'Checked Out'),
(76, 32, FALSE, NULL, '2025-06-12', '2025-06-15', '2025-06-15 10:00:00', 'Online', 'Checked Out'),
(77, 19, TRUE, 5, '2025-06-18', '2025-06-21', '2025-06-21 10:00:00', 'Online', 'Checked Out'),
(78, 37, FALSE, NULL, '2025-06-25', '2025-06-28', '2025-06-28 10:00:00', 'Phone', 'Checked Out'),
(79, 11, TRUE, 14, '2025-06-30', '2025-07-03', '2025-07-03 10:00:00', 'Online', 'Checked Out'),
(80, 5, FALSE, NULL, '2025-07-06', '2025-07-10', '2025-07-10 10:00:00', 'Travel Agent', 'Checked Out'),
(81, 30, TRUE, 3, '2025-07-12', '2025-07-15', '2025-07-15 10:00:00', 'Online', 'Checked Out'),
(82, 22, FALSE, NULL, '2025-07-18', '2025-07-21', '2025-07-21 10:00:00', 'Email', 'Checked Out'),
(83, 14, TRUE, 6, '2025-07-25', '2025-07-29', '2025-07-29 10:00:00', 'Online', 'Checked Out'),
(84, 46, FALSE, NULL, '2025-07-31', '2025-08-03', '2025-08-03 10:00:00', 'Phone', 'Checked Out'),
(85, 7, TRUE, 15, '2025-08-05', '2025-08-09', '2025-08-09 10:00:00', 'Online', 'Checked Out'),
(86, 28, FALSE, NULL, '2025-08-12', '2025-08-15', '2025-08-15 10:00:00', 'Travel Agent', 'Checked Out'),
(87, 33, TRUE, 10, '2025-08-18', '2025-08-21', '2025-08-21 10:00:00', 'Online', 'Checked Out'),
(88, 18, FALSE, NULL, '2025-08-24', '2025-08-27', '2025-08-27 10:00:00', 'Email', 'Checked Out'),
(89, 49, TRUE, 8, '2025-08-30', '2025-09-03', '2025-09-03 10:00:00', 'Online', 'Checked Out'),
(90, 9, FALSE, NULL, '2025-09-05', '2025-09-08', '2025-09-08 10:00:00', 'Phone', 'Checked Out'),
(91, 12, TRUE, 13, '2025-09-11', '2025-09-15', '2025-09-15 10:00:00', 'Online', 'Checked Out'),
(92, 45, FALSE, NULL, '2025-09-18', '2025-09-21', '2025-09-21 10:00:00', 'Travel Agent', 'Checked Out'),
(93, 4, TRUE, 1, '2025-09-25', '2025-09-28', '2025-09-28 10:00:00', 'Online', 'Checked Out'),
(94, 31, FALSE, NULL, '2025-10-01', '2025-10-04', '2025-10-04 10:00:00', 'Email', 'Checked Out'),
(95, 27, TRUE, 9, '2025-10-08', '2025-10-11', '2025-10-11 10:00:00', 'Online', 'Checked Out'),
(96, 6, FALSE, NULL, '2025-10-15', '2025-10-18', '2025-10-18 10:00:00', 'Phone', 'Checked Out'),
(97, 20, TRUE, 12, '2025-10-22', '2025-10-25', '2025-10-25 10:00:00', 'Online', 'Checked Out'),
(98, 48, FALSE, NULL, '2025-10-29', '2025-11-02', '2025-11-02 10:00:00', 'Travel Agent', 'Checked Out'),
(99, 36, TRUE, 5, '2025-11-05', '2025-11-08', '2025-11-08 10:00:00', 'Email', 'Checked Out'),
(100, 3, FALSE, NULL, '2025-11-12', '2025-11-15', '2025-11-15 10:00:00', 'Online', 'Checked Out'),
(101, 2, TRUE, 14, '2025-11-18', '2025-11-21', '2025-11-21 10:00:00', 'Online', 'Checked Out'),
(102, 43, FALSE, NULL, '2025-11-25', '2025-11-27', '2025-11-27 10:00:00', 'Phone', 'Checked Out'),
(103, 10, TRUE, 7, '2025-11-29', '2025-12-03', '2025-12-03 10:00:00', 'Online', 'Checked Out'),
(104, 22, FALSE, NULL, '2025-12-05', '2025-12-07', NULL, 'Email', 'Checked In'),
(105, 15, TRUE, 11, '2025-12-10', '2025-12-14', NULL, 'Online', 'Pending'),
(106, 24, FALSE, NULL, '2025-12-18', '2025-12-21', NULL, 'Travel Agent', 'Confirmed'),
(107, 29, TRUE, 3, '2025-12-24', '2025-12-27', NULL, 'Online', 'Pending'),
(108, 37, FALSE, NULL, '2025-12-29', '2026-01-01', NULL, 'Phone', 'Confirmed'),
(109, 8, TRUE, 6, '2024-02-04', '2024-02-07', '2024-02-07 10:00:00', 'Online', 'Checked Out'),
(110, 40, FALSE, NULL, '2024-03-01', '2024-03-04', '2024-03-04 10:00:00', 'Email', 'Checked Out'),
(111, 11, TRUE, 15, '2024-04-02', '2024-04-05', '2024-04-05 10:00:00', 'Travel Agent', 'Checked Out'),
(112, 33, FALSE, NULL, '2024-04-20', '2024-04-23', '2024-04-23 10:00:00', 'Online', 'Checked Out'),
(113, 19, TRUE, 5, '2024-05-10', '2024-05-12', '2024-05-12 10:00:00', 'Phone', 'Checked Out'),
(114, 16, FALSE, NULL, '2024-06-01', '2024-06-03', '2024-06-03 10:00:00', 'Online', 'Checked Out'),
(115, 30, TRUE, 8, '2024-06-18', '2024-06-21', '2024-06-21 10:00:00', 'Travel Agent', 'Checked Out'),
(116, 5, FALSE, NULL, '2024-07-05', '2024-07-08', '2024-07-08 10:00:00', 'Online', 'Checked Out'),
(117, 21, TRUE, 2, '2024-07-22', '2024-07-25', '2024-07-25 10:00:00', 'Email', 'Checked Out'),
(118, 14, FALSE, NULL, '2024-08-01', '2024-08-05', '2024-08-05 10:00:00', 'Online', 'Checked Out'),
(119, 36, TRUE, 13, '2024-08-10', '2024-08-14', '2024-08-14 10:00:00', 'Phone', 'Checked Out'),
(120, 9, FALSE, NULL, '2024-08-20', '2024-08-23', '2024-08-23 10:00:00', 'Online', 'Checked Out'),
(121, 44, TRUE, 4, '2024-09-01', '2024-09-04', '2024-09-04 10:00:00', 'Email', 'Checked Out'),
(122, 12, FALSE, NULL, '2024-09-10', '2024-09-14', '2024-09-14 10:00:00', 'Online', 'Checked Out'),
(123, 3, TRUE, 11, '2024-09-22', '2024-09-25', '2024-09-25 10:00:00', 'Phone', 'Checked Out'),
(124, 18, FALSE, NULL, '2024-10-05', '2024-10-07', '2024-10-07 10:00:00', 'Online', 'Checked Out'),
(125, 27, TRUE, 10, '2024-10-12', '2024-10-15', '2024-10-15 10:00:00', 'Travel Agent', 'Checked Out'),
(126, 32, FALSE, NULL, '2024-10-22', '2024-10-26', '2024-10-26 10:00:00', 'Online', 'Checked Out'),
(127, 50, TRUE, 6, '2024-11-01', '2024-11-04', '2024-11-04 10:00:00', 'Email', 'Checked Out'),
(128, 7, FALSE, NULL, '2024-11-10', '2024-11-13', '2024-11-13 10:00:00', 'Online', 'Checked Out'),
(129, 17, TRUE, 1, '2024-11-18', '2024-11-20', '2024-11-20 10:00:00', 'Phone', 'Checked Out'),
(130, 29, FALSE, NULL, '2024-11-25', '2024-11-28', '2024-11-28 10:00:00', 'Online', 'Checked Out'),
(131, 41, TRUE, 9, '2024-12-02', '2024-12-05', '2024-12-05 10:00:00', 'Travel Agent', 'Checked Out'),
(132, 24, FALSE, NULL, '2024-12-09', '2024-12-11', '2024-12-11 10:00:00', 'Online', 'Checked Out'),
(133, 4, TRUE, 12, '2024-12-15', '2024-12-18', '2024-12-18 10:00:00', 'Email', 'Checked Out'),
(134, 23, FALSE, NULL, '2024-12-22', '2024-12-26', '2024-12-26 10:00:00', 'Online', 'Checked Out'),
(135, 10, TRUE, 7, '2024-12-28', '2024-12-31', '2024-12-31 10:00:00', 'Phone', 'Checked Out'),
(136, 46, FALSE, NULL, '2025-01-03', '2025-01-06', '2025-01-06 10:00:00', 'Online', 'Checked Out'),
(137, 2, TRUE, 5, '2025-01-10', '2025-01-13', '2025-01-13 10:00:00', 'Travel Agent', 'Checked Out'),
(138, 39, FALSE, NULL, '2025-01-18', '2025-01-21', '2025-01-21 10:00:00', 'Online', 'Checked Out'),
(139, 31, TRUE, 14, '2025-01-26', '2025-01-29', '2025-01-29 10:00:00', 'Phone', 'Checked Out'),
(140, 35, FALSE, NULL, '2025-02-01', '2025-02-04', '2025-02-04 10:00:00', 'Online', 'Checked Out'),
(141, 25, TRUE, 15, '2025-02-07', '2025-02-10', '2025-02-10 10:00:00', 'Email', 'Checked Out'),
(142, 22, FALSE, NULL, '2025-02-13', '2025-02-16', '2025-02-16 10:00:00', 'Online', 'Checked Out'),
(143, 6, TRUE, 3, '2025-02-20', '2025-02-24', '2025-02-24 10:00:00', 'Travel Agent', 'Checked Out'),
(144, 49, FALSE, NULL, '2025-02-28', '2025-03-02', '2025-03-02 10:00:00', 'Online', 'Checked Out'),
(145, 11, TRUE, 13, '2025-03-04', '2025-03-07', '2025-03-07 10:00:00', 'Phone', 'Checked Out'),
(146, 8, FALSE, NULL, '2025-03-11', '2025-03-15', '2025-03-15 10:00:00', 'Online', 'Checked Out'),
(147, 44, TRUE, 2, '2025-03-18', '2025-03-21', '2025-03-21 10:00:00', 'Email', 'Checked Out'),
(148, 33, FALSE, NULL, '2025-03-25', '2025-03-29', '2025-03-29 10:00:00', 'Online', 'Checked Out'),
(149, 18, TRUE, 4, '2025-04-02', '2025-04-05', '2025-04-05 10:00:00', 'Travel Agent', 'Checked Out'),
(150, 13, FALSE, NULL, '2025-04-10', '2025-04-13', '2025-04-13 10:00:00', 'Online', 'Checked Out');

#need fixing
INSERT INTO room_assignment (reservationID, roomID) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);


INSERT INTO meeting_room_reservation (meetingRoomReservationID, reservationsReserved, startDate, endDate, description) VALUES
(1, 1, '2024-11-01 09:00:00', '2024-11-01 17:00:00', 'Corporate Strategy Meeting'),
(2, 3, '2024-11-03 10:00:00', '2024-11-03 15:00:00', 'Product Launch'),
(3, 8, '2024-11-08 08:00:00', '2024-11-10 20:00:00', 'Annual Conference'),
(4, 13, '2024-11-13 09:00:00', '2024-11-13 16:00:00', 'Team Building Workshop'),
(5, 18, '2024-11-18 10:00:00', '2024-11-18 18:00:00', 'Investor Meeting'),
(6, 23, '2024-11-23 08:30:00', '2024-11-23 16:30:00', 'Training Session'),
(7, 28, '2024-11-28 09:00:00', '2024-11-28 17:00:00', 'Board Meeting'),
(8, 33, '2024-12-03 10:00:00', '2024-12-03 15:00:00', 'Client Presentation'),
(9, 38, '2024-12-08 08:00:00', '2024-12-10 20:00:00', 'Industry Conference'),
(10, 43, '2024-12-13 09:00:00', '2024-12-13 16:00:00', 'Workshop');

-- INSERT INTO rec_room_reservation (recRoomReservationID, recRoomType, reservationsReserved) VALUES
-- (1, 1, 5),
-- (2, 2, 10),
-- (3, 3, 15),
-- (4, 1, 20),
-- (5, 2, 25),
-- (6, 3, 30),
-- (7, 1, 35),
-- (8, 2, 40),
-- (9, 3, 45),
-- (10, 1, 50);

INSERT INTO billing (billingID, reservationID, customerID) VALUES
(1, 3, 12),
(2, 7, 5),
(3, 12, 18),
(4, 20, 7),
(5, 25, 22),
(6, 31, 9),
(7, 40, 30),
(8, 45, 11),
(9, 51, 6),
(10, 58, 27),

(11, 63, 15),
(12, 70, 3),
(13, 75, 41),
(14, 82, 10),
(15, 90, 33),
(16, 95, 21),
(17, 100, 48),
(18, 108, 44),
(19, 115, 37),
(20, 121, 29),

(21, 126, 19),
(22, 130, 8),
(23, 134, 25),
(24, 138, 14),
(25, 142, 32),
(26, 145, 4),
(27, 147, 46),
(28, 149, 13),
(29, 150, 2),
(30, 72, 28);

INSERT INTO payment (paymentID, billingID, date, method) VALUES
(1, 1, '2024-01-05', 'Credit Card'),
(2, 1, '2024-01-06', 'Credit Card'),
(3, 2, '2024-01-08', 'Mobile Pay'),
(4, 3, '2024-01-09', 'Debit Card'),
(5, 4, '2024-01-10', 'Online Banking'),
(6, 5, '2024-01-12', 'Cash'),
(7, 6, '2024-01-12', 'Credit Card'),
(8, 7, '2024-01-13', 'Credit Card'),
(9, 8, '2024-01-13', 'Mobile Pay'),
(10, 9, '2024-01-14', 'Debit Card'),

(11, 10, '2024-01-15', 'Credit Card'),
(12, 11, '2024-01-16', 'Online Banking'),
(13, 12, '2024-01-17', 'Cash'),
(14, 13, '2024-01-18', 'Debit Card'),
(15, 14, '2024-01-18', 'Credit Card'),
(16, 15, '2024-01-19', 'Mobile Pay'),
(17, 16, '2024-01-19', 'Credit Card'),
(18, 17, '2024-01-20', 'Credit Card'),
(19, 18, '2024-01-21', 'Online Banking'),
(20, 19, '2024-01-21', 'Cash'),

(21, 20, '2024-01-22', 'Credit Card'),
(22, 21, '2024-01-23', 'Mobile Pay'),
(23, 22, '2024-01-23', 'Online Banking'),
(24, 23, '2024-01-24', 'Debit Card'),
(25, 24, '2024-01-25', 'Cash'),
(26, 25, '2024-01-25', 'Credit Card'),
(27, 26, '2024-01-26', 'Credit Card'),
(28, 27, '2024-01-26', 'Mobile Pay'),
(29, 28, '2024-01-27', 'Debit Card'),
(30, 29, '2024-01-28', 'Online Banking'),

(31, 30, '2024-01-28', 'Online Banking'),
(32, 12, '2024-01-29', 'Credit Card'),
(33, 4, '2024-01-29', 'Mobile Pay'),
(34, 7, '2024-01-30', 'Credit Card'),
(35, 14, '2024-01-30', 'Cash'),
(36, 19, '2024-01-30', 'Debit Card'),
(37, 21, '2024-01-31', 'Credit Card'),
(38, 22, '2024-02-01', 'Mobile Pay'),
(39, 23, '2024-02-01', 'Debit Card'),
(40, 25, '2024-02-02', 'Credit Card');

INSERT INTO customer_payment_relation (customerID, paymentID) VALUES
(12, 1),
(12, 2),
(5, 3),
(18, 4),
(7, 5),
(22, 6),
(9, 7),
(30, 8),
(11, 9),
(6, 10),

(27, 11),
(15, 12),
(3, 13),
(41, 14),
(10, 15),
(33, 16),
(21, 17),
(48, 18),
(44, 19),
(37, 20),

(29, 21),
(19, 22),
(8, 23),
(25, 24),
(14, 25),
(32, 26),
(4, 27),
(46, 28),
(13, 29),
(2, 30),

(28, 31),
(15, 32),
(7, 33),
(9, 34),
(10, 35),
(37, 36),
(29, 37),
(19, 38),
(8, 39),
(14, 40);


INSERT INTO charged_service_type (serviceTypeId, serviceDescription, price) VALUES
(1, 'Restaurant', 150),
(2, 'Phone call', 1),
(3, 'Laundary', 30),
(4, 'Spa Service', 200),
(5, 'Mini Bar', 75),
(6, 'Facility Use', 50),
(7, 'Delivery', 10),
(8, 'Extra Room Service', 10),
(9, 'Photocopying/Printing', 2),
(10, 'Computer Time', 10),
(11, 'Fax', 3),
(12, 'Retail Shops in Complex', 1);

INSERT INTO charged_service (chargedServiceId, serviceTypeId, reservationID, customerID, amount, time) VALUES
(1, 1, 12, 5, 150.00, '2024-01-03'),
(2, 3, 44, 12, 30.00, '2024-01-04'),
(3, 5, 77, 8, 75.00, '2024-01-05'),
(4, 4, 88, 21, 200.00, '2024-01-05'),
(5, 2, 14, 3, 1.00, '2024-01-06'),
(6, 7, 33, 17, 10.00, '2024-01-06'),
(7, 8, 62, 29, 10.00, '2024-01-07'),
(8, 9, 91, 4, 2.00, '2024-01-07'),
(9, 10, 118, 41, 10.00, '2024-01-08'),
(10, 11, 147, 10, 3.00, '2024-01-08'),

(11, 12, 23, 15, 1.00, '2024-01-09'),
(12, 1, 145, 7, 150.00, '2024-01-10'),
(13, 3, 58, 11, 30.00, '2024-01-11'),
(14, 4, 121, 19, 200.00, '2024-01-11'),
(15, 6, 132, 27, 50.00, '2024-01-12'),
(16, 5, 74, 49, 75.00, '2024-01-12'),
(17, 7, 103, 38, 10.00, '2024-01-13'),
(18, 8, 9, 2, 10.00, '2024-01-13'),
(19, 9, 140, 25, 2.00, '2024-01-14'),
(20, 11, 37, 35, 3.00, '2024-01-14'),

(21, 1, 116, 44, 150.00, '2024-01-15'),
(22, 4, 87, 6, 200.00, '2024-01-15'),
(23, 10, 51, 9, 10.00, '2024-01-16'),
(24, 12, 133, 33, 1.00, '2024-01-16'),
(25, 5, 92, 14, 75.00, '2024-01-17'),
(26, 2, 120, 39, 1.00, '2024-01-17'),
(27, 3, 66, 20, 30.00, '2024-01-18'),
(28, 9, 49, 13, 2.00, '2024-01-18'),
(29, 6, 150, 48, 50.00, '2024-01-19'),
(30, 8, 82, 31, 10.00, '2024-01-19'),

(31, 7, 18, 22, 10.00, '2024-01-20'),
(32, 3, 27, 46, 30.00, '2024-01-20'),
(33, 5, 131, 9, 75.00, '2024-01-21'),
(34, 4, 110, 50, 200.00, '2024-01-21'),
(35, 12, 25, 18, 1.00, '2024-01-22'),
(36, 9, 138, 44, 2.00, '2024-01-22'),
(37, 2, 70, 30, 1.00, '2024-01-23'),
(38, 10, 146, 16, 10.00, '2024-01-23'),
(39, 6, 81, 5, 50.00, '2024-01-24'),
(40, 1, 134, 12, 150.00, '2024-01-24'),

(41, 8, 63, 7, 10.00, '2024-01-25'),
(42, 11, 142, 33, 3.00, '2024-01-25'),
(43, 5, 97, 25, 75.00, '2024-01-26'),
(44, 3, 41, 48, 30.00, '2024-01-26'),
(45, 4, 108, 36, 200.00, '2024-01-27'),
(46, 7, 12, 14, 10.00, '2024-01-27'),
(47, 6, 15, 2, 50.00, '2024-01-28'),
(48, 9, 89, 23, 2.00, '2024-01-28'),
(49, 2, 45, 4, 1.00, '2024-01-29'),
(50, 10, 122, 47, 10.00, '2024-01-29');


INSERT INTO staff_role (roleID, roleType, description) VALUES
(1, 'Receptionist', 'Front desk check-in/out'),
(2, 'Housekeeping', 'Room cleaning and maintenance'),
(3, 'Event Coordinator', 'Meeting and event planning'),
(4, 'Manager', 'Oversee operations and staff'),
(5, 'Concierge', 'Guest services and recommendations'),
(6, 'Chef', 'Food preparation and kitchen management'),
(7, 'Waiter', 'Food and beverage service'),
(8, 'Security', 'Safety and security management'),
(9, 'Maintenance', 'Building and equipment repair'),
(10, 'Accountant', 'Financial management and billing');

INSERT INTO staff (staffID, name, gender, hireDate, department, phone) VALUES
(1, 'Michael Chen', 'Male', '2020-03-15', 'Front Desk', '+1-555-0201'),
(2, 'Emily White', 'Female', '2021-06-22', 'Housekeeping', '+1-555-0202'),
(3, 'Daniel Lee', 'Male', '2019-11-30', 'Events', '+1-555-0203'),
(4, 'Jessica Brown', 'Female', '2022-01-10', 'Management', '+1-555-0204'),
(5, 'Carlos Rodriguez', 'Male', '2023-08-05', 'Concierge', '+1-555-0205'),
(6, 'Sophia Martinez', 'Female', '2020-09-12', 'Kitchen', '+1-555-0206'),
(7, 'James Wilson', 'Male', '2021-03-25', 'Restaurant', '+1-555-0207'),
(8, 'Olivia Taylor', 'Female', '2022-07-18', 'Security', '+1-555-0208'),
(9, 'David Clark', 'Male', '2019-05-30', 'Maintenance', '+1-555-0209'),
(10, 'Emma Anderson', 'Female', '2023-01-15', 'Finance', '+1-555-0210'),
(11, 'Robert Garcia', 'Male', '2020-11-08', 'Front Desk', '+1-555-0211'),
(12, 'Isabella Hernandez', 'Female', '2021-08-14', 'Housekeeping', '+1-555-0212'),
(13, 'William Martin', 'Male', '2022-04-30', 'Events', '+1-555-0213'),
(14, 'Mia Thompson', 'Female', '2023-10-22', 'Concierge', '+1-555-0214'),
(15, 'Joseph Moore', 'Male', '2020-12-05', 'Kitchen', '+1-555-0215');

INSERT INTO staff_assignment (staffID, roleID, reservationID, description) VALUES
(1, 1, 1, 'Check-in for reservation 1'),
(2, 2, 1, 'Room cleaning after checkout'),
(3, 3, 3, 'Event coordination for product launch'),
(4, 4, 8, 'Oversee annual conference'),
(5, 5, 10, 'Guest recommendations and services'),
(6, 6, 5, 'Prepare banquet for government event'),
(7, 7, 7, 'Serve meals for checked-in guests'),
(8, 8, 8, 'Security for large conference'),
(9, 9, 3, 'Repair HVAC in meeting room'),
(10, 10, 1, 'Process billing for reservation 1'),
(11, 1, 2, 'Check-in for corporate client'),
(12, 2, 2, 'Prepare room for new guest'),
(13, 3, 13, 'Coordinate team building workshop'),
(14, 5, 15, 'Assist with travel arrangements'),
(15, 6, 18, 'Prepare food for investor meeting');

INSERT INTO staff_log (logID, staffID, reservationID, action, time) VALUES
(1, 1, 1, 'Checked in guest', '2024-11-01 16:30:00'),
(2, 1, 1, 'Processed payment', '2024-11-05 11:45:00'),
(3, 2, 1, 'Cleaned room after checkout', '2024-11-05 14:20:00'),
(4, 3, 3, 'Set up meeting room', '2024-11-03 08:30:00'),
(5, 4, 8, 'Approved conference setup', '2024-11-08 09:15:00'),
(6, 5, 10, 'Made restaurant reservation for guest', '2024-11-10 18:00:00'),
(7, 6, 5, 'Prepared special menu', '2024-11-05 19:30:00'),
(8, 7, 7, 'Served room service', '2024-11-07 20:15:00'),
(9, 8, 8, 'Conducted security check', '2024-11-08 22:00:00'),
(10, 9, 3, 'Fixed projector in meeting room', '2024-11-03 10:45:00'),
(11, 10, 1, 'Generated final bill', '2024-11-05 12:15:00'),
(12, 11, 2, 'Assisted with luggage', '2024-11-02 17:30:00'),
(13, 12, 2, 'Turned down room', '2024-11-02 20:00:00'),
(14, 13, 13, 'Organized workshop materials', '2024-11-13 07:45:00'),
(15, 14, 15, 'Booked taxi for guest', '2024-11-15 16:20:00');

